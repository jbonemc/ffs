
from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_admin import Admin, expose, BaseView
from flask_admin.contrib.sqla import ModelView
from datetime import datetime

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///waitlist.db'
app.config['SECRET_KEY'] = 'secret_key'
db = SQLAlchemy(app)

class Player(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    is_waitlisted = db.Column(db.Boolean, default=False)

class GameConfig(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    game_time = db.Column(db.String(120), nullable=True)
    revolut_link = db.Column(db.String(500), nullable=True)

class AdminView(BaseView):
    @expose('/', methods=['GET', 'POST'])
    def index(self):
        if request.method == 'POST':
            if request.form.get('password') == 'f00tball':
                return redirect(url_for('admin_config'))
        return self.render('admin_login.html')

class ConfigView(BaseView):
    @expose('/', methods=['GET', 'POST'])
    def index(self):
        config = GameConfig.query.first() or GameConfig()
        if request.method == 'POST':
            config.game_time = request.form['game_time']
            config.revolut_link = request.form['revolut_link']
            if not config.id:
                db.session.add(config)
            db.session.commit()
            return redirect(url_for('index'))
        return self.render('config.html', config=config)

admin = Admin(app)
admin.add_view(AdminView(name='Login', endpoint='admin_login'))
admin.add_view(ConfigView(name='Config', endpoint='admin_config'))

@app.route('/')
def index():
    players = Player.query.filter_by(is_waitlisted=False).all()
    waitlist = Player.query.filter_by(is_waitlisted=True).all()
    config = GameConfig.query.first()
    return render_template('index.html', players=players, waitlist=waitlist, config=config)

@app.route('/join', methods=['POST'])
def join():
    name = request.form['name']
    if not name:
        return redirect(url_for('index'))

    total_players = Player.query.filter_by(is_waitlisted=False).count()
    is_waitlisted = total_players >= 14
    new_player = Player(name=name, is_waitlisted=is_waitlisted)
    db.session.add(new_player)
    db.session.commit()

    return redirect(url_for('index'))

@app.route('/remove/<int:player_id>')
def remove(player_id):
    player = Player.query.get(player_id)
    if player:
        db.session.delete(player)
        db.session.commit()
        # Fill the main spots from the waitlist if available
        if not player.is_waitlisted:
            next_waitlisted = Player.query.filter_by(is_waitlisted=True).first()
            if next_waitlisted:
                next_waitlisted.is_waitlisted = False
                db.session.commit()

    return redirect(url_for('index'))

if __name__ == '__main__':
    db.create_all()
    app.run(debug=True)
    